package com.spring.SpringCloudServiceAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudServiceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudServiceApiApplication.class, args);
	}

}
